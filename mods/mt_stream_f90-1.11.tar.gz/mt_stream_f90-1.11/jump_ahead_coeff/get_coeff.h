extern "C"
void get_coeff (const int& nn,
                const int& mm,
                const int& rr,
                const int& ww,
                const int& avec,
                const int& nj,
                const int& id,
                unsigned int *pp,
                int& np);
